<html>
    <head>
        <title>Changelog & Credits</title>
    </head>

            <style>
                body
                    {
                        background: rgb(203,255,225);
                        background: linear-gradient(36deg, rgba(203,255,225,1) 0%, rgba(140,173,213,1) 100%);
                    }
                
                .div
                            {
                                background-color:black;
                                color: green;
                                width: 85%;
                                height:85%;
                                margin: auto;
                                margin-top: 4%;
                                padding: 2px;
                            }

            </style>
    <body>
        <div class="div">
            IT Solution software is a web based application. It can helps to automatic task providation to staff.
            This application is under <a style="color:green;"href="https://en.wikipedia.org/wiki/GNU_General_Public_License#:~:
            text=The%20GNU%20General%20Public%20License,share%2C%20and%20modify%20the%20software.">GNU (General Public 
            License) license</a> and proprietorship by <a href="https://tanmoymaity.in" style="color:green;">Tanmoy Maity</a>.
            <br><br><br><hr>
                <p style="color:skyblue">
                    <u>Changelog</u>
                    <br><br>
                    1. Create unlimited user with login permission utility.<br><br>
                    2. There is an Task deletion, restore facility. <br><br>
                    3. Progress statemtment can note in this application by all user.
                    4. Real time work Report can be generated.<br>
                </p>
                <br>
<br><br>
              <div align="center" style="font-size: 50px;color:white;font-family:cursive">THANK YOU</div>
              <br><br><br><br><br><br>
                    <hr>
                            <a style="color:white"  href="/">GO BACK</a>
        </div>
    <body>
</html>
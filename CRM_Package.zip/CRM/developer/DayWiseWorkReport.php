<?php

    include ('appcode/session.php');

    include ('appcode/config.php');

    include ('master.php');

    

    $vusername=$_SESSION['username'];

   $sql1 = "SELECT * FROM users WHERE username='$vusername'";

       if($result = mysqli_query($con,$sql1))

           {

               if(mysqli_num_rows($result) > 0)

                   {

                       while($row = mysqli_fetch_array($result))

                           {

                               $vname=$row['name'];

                           }

                   }

           }

?>



<html>

    <head>

        <title>Day Wise Work Status | Developer & Designer</title>

        <link href='css/sheet2.css' rel='stylesheet'/>

        <style>

            body

                    {

                        background-image: url('src/banner.jpg');

                        background-repeat: no-repeat;

                        background-size: 100% 100%;

                        z-index: -999;

                        counter-reset: Serial;

                    }

            .alert

                    {

                        color: red;

                        font-size: large;

                        font-family: 'Times New Roman', Times, serif

                    }

            #customers

                    {

                    font-family: Arial, Helvetica, sans-serif;

                    border-collapse: collapse;

                    width: 100%;

                    text-align:center;

                    }



            #customers td, #customers th

                                        {

                                        border: 1px solid #ddd;

                                        padding: 8px;

                                        }



            #customers tr:nth-child(even){background-color: #f2f2f2;}



            #customers tr:hover {background-color: #ddd;}



            #customers th

                        {

                        padding-top: 12px;

                        padding-bottom: 12px;

                        text-align: left;

                        background-color: #04AA6D;

                        color: white;

                        }



        tr td:first-child:before

                            {

                            counter-increment: Serial;      

                            content: counter(Serial); 

                            }

        </style>

    </head>

    <body>
    <script src="js/unseen.js"></script>
<form action="" method="POST">

    <input type='date' name="inp_date" class="">

    <button name="CWCW" class="">Show Report</button>

</form>



<?php

            if(isset($_POST['CWCW']))

            {

                    include ('appcode/config.php');

                    $ddate=$_POST['inp_date'];

                    echo $ddate;

                    echo "<div class='form_b' style='width:98%'>";

                    echo "<h2 align='center'>Day Wise Task Report</h2>";

                    date_default_timezone_set("Asia/Calcutta");

                    echo"<div style='float:left;'>For the Date of  ".date("d/m/Y", strtotime($ddate))."</div>";

                    echo"<div style='float:right;'>Generated on: ".date('d/m/Y  h:i:s a')."</div>";

                    echo"<table id='customers'>";

                        echo"<tr>";

                            echo"<th>Sl No.</th>";

                            echo"<th>Working Date</th>";

                            echo"<th>College Name</th>";

                            echo"<th>Attachment</th>";

                            echo"<th>Notes</th>";

                            echo"<th>Alloted To</th>";

                            echo"<th>Work Status</th>";

                        echo "</tr>";



                        $query1="SELECT * FROM task_info WHERE work_status=1 AND deleted='0' AND alloted_to='$vname' AND develop_on='$ddate'";

                        if($result=mysqli_query($con,$query1))

                        {

                            if(mysqli_num_rows($result) > 0)

                            {

                                while($row = mysqli_fetch_array($result))

                                {

                                    $originalDate1 = $row['develop_on'];

                                    $newDate1 = date("d/m/Y", strtotime($originalDate1));

                                    

                                    echo"<form align='center' action='' method='POST'>";



                                    echo "<tr>";

                                        echo "<td></td>";

                                        echo "<td>".$newDate1."</td>";

                                        echo "<td>".$row['college_name']."</td>";

                                        echo "<td><a href='upload/".$row['datafile']."'>Attached File</a></td>";

                                        echo "<td>".$row['notes']."</td>";

                                        echo "<td>".$row['alloted_to']."</td>";

                                        if($row['work_status']==1){$wst="Done";}

                                        echo"<td>".$wst."</td>";

                                    echo "</tr>";

                                }

                            }

                        }



                echo"</table>";

            }

        ?>

        </div>

    </body>

</html>
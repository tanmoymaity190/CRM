<?php
    include ('appcode/session.php');
    include ('appcode/config.php');
    include ('master.php');
    $alert="";
    $alert1="";

    date_default_timezone_set("Asia/Calcutta");
    $odate=date('d/m/Y H:i:s a');
?>

<html>
    <head>
        <title>User Status | Admin</title>
        <link href='css/sheet2.css' rel='stylesheet'/>
        <style>
            body
                    {
                        background-image: url('src/banner.jpg');
                        background-repeat: no-repeat;
                        background-size: 100% 100%;
                        z-index: -999;
                        counter-reset: Serial;
                    }
            .alert
                    {
                        color: red;
                        font-size: large;
                        font-family: 'Times New Roman', Times, serif
                    }
            #customers
                    {
                    font-family: Arial, Helvetica, sans-serif;
                    border-collapse: collapse;
                    width: 100%;
                    text-align:center;
                    }

            #customers td, #customers th
                                        {
                                        border: 1px solid #ddd;
                                        padding: 8px;
                                        }

            #customers tr:nth-child(even){background-color: #f2f2f2;}

            #customers tr:hover {background-color: #ddd;}

            #customers th
                        {
                        padding-top: 12px;
                        padding-bottom: 12px;
                        text-align: left;
                        background-color: #04AA6D;
                        color: white;
                        }

        tr td:first-child:before
                            {
                            counter-increment: Serial;      
                            content: counter(Serial); 
                            }
        </style>
    </head>

<?php
    if(isset($_POST['done']))
    {
        $id=$_POST['pid'];
        date_default_timezone_set("Asia/Calcutta");
        $dev_date=date('Y-m-d');
        $done_query="UPDATE task_info SET work_status='1',develop_on='$dev_date' WHERE id='$id'";
        if(mysqli_query($con,$done_query))
        {
            $alert="Task id ".$id." is markrd as Done!";
        }
    }

    if(isset($_POST['nodone']))
    {
        $id=$_POST['pid'];
        $nodone_query="UPDATE task_info SET work_status='0',develop_on='' WHERE id='$id'";
        if(mysqli_query($con,$nodone_query))
        {
            $alert="Task id ".$id." is markrd as Done!";
        }
    }

    if(isset($_POST['NotesUpdate']))
    {
        include ('appcode/config.php');
        $old_task="";
            $WID=$_POST['wid'];
            $notes=$_POST['notes'];

            $name=$_SESSION['username'];
                        $str3="SELECT name FROM users WHERE username='$name'";

                        if($str4=mysqli_query($con,$str3))
                        {
                        if(mysqli_num_rows($str4) > 0)
                        {
                        while($row2 = mysqli_fetch_array($str4))
                        {
                            $old_name=$row2['name'];
                            
                        }
                        }
                        }



                    $str1="SELECT notes FROM task_info WHERE id='$WID'";

                        if($str2=mysqli_query($con,$str1))
                        {
                        if(mysqli_num_rows($str2) > 0)
                        {
                        while($row1 = mysqli_fetch_array($str2))
                        {
                            $old_task=$row1['notes'];
                           
                        }
                        }
                        }


                        

                        $final_note=$old_task." <br>".$old_name." (".$odate.") : ".$notes;
                        
                $find="UPDATE task_info SET notes='$final_note' WHERE id='$WID'";
                if(mysqli_query($con,$find))
                {
                    $alert1="Notes Updated Successfully";
                }
                else
                {
                    echo mysqli_error($con);
                }
    }
?>
    <body>
    <script src="js/unseen.js"></script>
        <div class='form_b' style='overflow:scroll;width:98%'>
                <table id="customers">
                    <tr>
                        <th>Sl No.</th>
                        <th>Select</th>
                        <th>Date</th>
                        <th>Entry By</th>
                        <th>College Name</th>
                        <th>Attachment</th>
                        <th>Notes</th>
                        <th>Alloted To</th>
                        <th>Work Status</th>
                    </tr>

                    <?php
                        $dname=$_SESSION['reg'];
                        $view_table="SELECT * FROM task_info WHERE deleted='0' AND work_status='0' AND alloted_to='$dname' ORDER BY ddate";
                        if($result=mysqli_query($con,$view_table))
                        {
                            if(mysqli_num_rows($result) > 0)
                            {
                                while($row = mysqli_fetch_array($result))
                                {
                                    $originalDate = $row['ddate'];
                                    $newDate = date("d/m/Y", strtotime($originalDate));
                                    
                                    $originalDate1 = $row['develop_on'];
                                    $newDate1 = date("d/m/Y", strtotime($originalDate1));
                                    
                                    echo"<form align='center' action='' method='POST'>";
                                    if($row['work_status']=='0'){$wst="Not Done";}else{$wst="Done";}
                                    echo "<tr>";
                                        echo "<td></td>";
                                        echo "<td><input type='radio' name='pid' value='".$row['id']."'></td>";
                                        echo "<td>".$newDate."</td>";
                                        echo "<td>".$row['entry_by']."</td>";
                                        echo "<td>".$row['college_name']."<br>Work ID :".$row['id']."</td>";
                                        echo "<td><a href='/support/upload/".$row['datafile']."'>Attached File</a></td>";
                                        echo "<td>".$row['notes']."</td>";
                                        echo "<td>".$row['alloted_to']."</td>";
                                        echo "<td>".$wst." (".$newDate1.")</td>";
                                    echo "</tr>";
                                }
                            }
                        }
                    ?>
                </table>
        </div>

                    <div class='form_c' align='center'>
                            <br><br><?php echo "<div class='alert'>".$alert."</div>";?>
                            <button name='done' class='button8'>Work Done</button><br><br>
                            <button name='nodone' style='width:82%' class='button7'>Not Done</button><br><br>
                    </div>

                    <div class='form_c' style='margin-top:-142px; margin-left:112px;' align='center'>
                    <form action='' method='POST'>
                        <input type='number' class='input_fild' name='wid' placeholder='Enter Work ID'/><br><br>
                        <textarea name='notes' class='input_fild' placeholder='Enter Your Notes.....'></textarea><br><br>
                        <div class='alert'><?php echo $alert1;?></div>
                        <button name='NotesUpdate' class='button8'>Update</button>
                    </form>
                </div>
        </div>
    </body>
</html>
<?php
    include ('appcode/session.php');
    include ('master.php');
?>

<?php
        $alert="";
    if(isset($_POST['UCreate']))
    {
        include ('appcode/config.php');

        $employee_name=$_POST['employee_name'];
        $employee_code=$_POST['employee_code'];
        $UserRole=$_POST['UserRole'];
        $username=$_POST['uname'];
        $rawpasswd=$_POST['passwd'];
            $passwd=md5($rawpasswd);

            $user_query="INSERT INTO users (name,username,password,emp_code,userrole,cstatus)
            VALUES ('$employee_name','$username','$passwd','$employee_code','$UserRole','0')";

            if(mysqli_query($con,$user_query))
                {
                    $alert="User Created Successfully";
                    mysqli_close($con);
                }
    }
?>
<html>
    <head>
        <title>User Creation | IT Solution</title>
        <link href='css/sheet2.css' rel='stylesheet'/>
        <style>
            body
                    {
                        background-image: url('src/banner.jpg');
                        background-repeat: no-repeat;
                        background-size: 100% 100%;
                        z-index: -999;
                    }
            .alert
                    {
                        color: red;
                        font-size: large;
                        font-family: 'Times New Roman', Times, serif
                    }
        </style>
    </head>

    <body>
    <script href="js/unseen.js"></script>
        <form action='' method='POST' class='form_a' align='center'>
            <h2><center>User Creation</center><hr>
            <input type='text' class='input_a' name='employee_name' placeholder='Enter Full Name of Employee' required/><br><br>
            <input type='text' class='input_a' name='employee_code' placeholder='Enter Employee Code' required/><br><br>
                <select name='UserRole' class='input_a' required>
                    <option value='select'>--select--</option>
                    <option value='Designer'>Designer</option>
                    <option value='Developer'>Developer</option>
                    <option value='Supporter'>Supporter</option>
                <select><br><br>
            <input type='text' class='input_a' name='uname' placeholder='Enter Username' required/><br><br>
            <input type='text' class='input_a' name='passwd' placeholder='Enter Password' required/><br><br>
                <?php echo "<div class='alert'>".$alert."</div>";?>
            <button name='UCreate' class='button5'>Create</button>
        </form>
    </body>
</html>
<html>
    <head>
    <link href="/asset/banner/favicon.png" rel="icon">
        <style>
            .navbar
                    {
                        overflow: hidden;
                        background-color: #333;
                        width: 101.5%;
                        margin-left: -1%;
                        margin-top: -1%;
                    }

            .navbar a
                    {
                        float: left;
                        font-size: 16px;
                        color: white;
                        font-weight:bold;
                        font-family: 'Times New Roman', Times, serif;
                        text-align: center;
                        padding: 1% 3%;
                        text-decoration: none;
                    }

            .subnav
                    {
                        float: left;
                        overflow: hidden;
                    }

            .subnav .subnavbtn
                            {
                                font-size: 16px;  
                                border: none;
                                outline: none;
                                color: white;
                                padding: 14px 16px;
                                background-color: inherit;
                                font-family: inherit;
                                margin: 0;
                            }

            .navbar a:hover, .subnav:hover .subnavbtn {background-color: dodgerblue;}

            .subnav-content
                            {
                                display: none;
                                position: absolute;
                                left: 0;
                                background-color: dodgerblue;
                                width: 100%;
                                z-index: 1;
                            }

            .subnav-content a
                            {
                                float: left;
                                color: white;
                                text-decoration: none;
                            }

            .subnav-content a:hover {
                                        background-color: #eee;
                                        color: black;
                                    }

            .subnav:hover .subnav-content {display: block;}
        </style>

        <body>
        <script href="js/unseen.js"></script>
            <div class="navbar">
                <a href='admindashboard.php'>Home</a>

                <div class="subnav">
                    <button class="subnavbtn">Administration <i class="fa fa-caret-down"></i></button>
                        <div class="subnav-content">
                            <a href="UserCreation.php">User Creation</a>
                            <a href="UserStatus.php">User Status Update</a>
                        </div>
                </div>

                <a href='logout.php'>Logout</a>

            </div>
               
        </body>
    </head>
</html>
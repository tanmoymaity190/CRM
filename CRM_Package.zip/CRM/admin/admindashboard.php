<?php

    include ('appcode/session.php');

    include ('master.php');

?>

<html>

    <head>

        <title>Admin Dashboard</title>

        <style>

                body

                    {

                        background-image: url('src/banner.jpg');

                        background-repeat: no-repeat;

                        background-size: 100% 100%;

                        z-index: -999;

                    }

                

                .portal

                        {

                            color:white;

                            font-size:35px;

                            margin-left:66%;

                            margin-top:20%

                        }

        </style>

    </head>



    <body>
        <script href="js/unseen.js"></script>
        <div class='portal'>Administrator Portal</div>

    </body>

</html>
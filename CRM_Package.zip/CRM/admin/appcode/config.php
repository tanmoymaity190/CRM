<?php
    $SRV_HOST="localhost";
    $SRV_USERNAME="root";
    $SRV_PASSWORD="";
    $SRV_DATABASE="cab_24_db";

        $con=mysqli_connect($SRV_HOST,$SRV_USERNAME,$SRV_PASSWORD,$SRV_DATABASE);

        if($con===false)
        {
            echo "<div class='alert'>Could not established connection with ".$SRV_HOST.". Please contact with System Administrator.</div>";
        }
?>
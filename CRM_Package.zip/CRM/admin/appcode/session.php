<?php
	session_start();
	   if(!isset($_SESSION["adloggedin"]) || $_SESSION["adloggedin"] !== true)
	   {
		 header("location: adminlogin.php");
		 exit();
	  } 
?>
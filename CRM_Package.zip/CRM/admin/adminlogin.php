<?php
        $alert="";
    if(isset($_POST['adlogin']))
    {
        include ('appcode/config.php');

        $username=$_POST['aduname'];
        $password=$_POST['adpasswd'];

        $login_query="SELECT * FROM sa_login WHERE username='$username' AND password='$password'";

        if(mysqli_query($con,$login_query))
        {
            $result=mysqli_query($con,$login_query);
            $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
            $count=mysqli_num_rows($result);

                if($count==1)
                {
                    session_start();
                    $_SESSION['adloggedin']=true;
                    $_SESSION["id"] = $id;
					$_SESSION["username"] = $uname;
                    mysqli_close($con);
                    header("location: admindashboard.php");
                }

                else
                    {
                        $alert="Login Failed!";
                    }
        }
    }
?>
<html>
    <head>
    <link href="/asset/banner/favicon.png" rel="icon">
        <title>Admin Login</title>
        <link href='css/sheet2.css' rel='stylesheet'/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <body>
    <script href="js/unseen.js"></script>
        <form class='Login' action='' method='POST' align='center'>
        <div style='font-size: 150px'><i class="fa fa-user-secret" aria-hidden="true"></i></div>
            <div style='font-size:40px;font-weight:bold'>Admin Login</div>
                    <span class=''></span>
                        <input type='text' name='aduname' class='input_fild' placeholder='Username' required/>
                            <br><br>

            <span class=''></span>
                <input type='password' name='adpasswd' class='input_fild' placeholder='Password' required/>
                    <br><br>
            <button class='button5' name='adlogin'>Login</button>
                        &nbsp;&nbsp;
            <input class='button6' value='Reset' type='reset'/>
                <div class="alert"><?php echo $alert;?></div>
        </form>
    </body>
</html>
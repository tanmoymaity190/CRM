<?php
    include ('appcode/session.php');
    include ('appcode/config.php');
    include ('master.php');

    if(isset($_POST['continue']))
    {
        $uid=$_POST['uid'];
        $sql_13="UPDATE users SET cstatus=1 WHERE id='$uid'";
        if(mysqli_query($con,$sql_13))
        {
            echo"<script>alert('User Assaigned as CONTINUE');</script>";
        }
    }
        if(isset($_POST['discontinue']))
        {
            $uid=$_POST['uid'];
            $sql_14="UPDATE users SET cstatus=0 WHERE id='$uid'";
            if(mysqli_query($con,$sql_14))
            {
                echo"<script>alert('User Assaigned as DISCONTINUED');</script>";
            }
        }
    
?>
<html>
    <head>
        <title>User Status | Admin</title>
        <link href='css/sheet2.css' rel='stylesheet'/>
        <style>
            body
                    {
                        background-image: url('src/banner.jpg');
                        background-repeat: no-repeat;
                        background-size: 100% 100%;
                        z-index: -999;
                        counter-reset: Serial;
                    }
            .alert
                    {
                        color: red;
                        font-size: large;
                        font-family: 'Times New Roman', Times, serif
                    }
            #customers
                    {
                    font-family: Arial, Helvetica, sans-serif;
                    border-collapse: collapse;
                    width: 100%;
                    text-align:center;
                    }

            #customers td, #customers th
                                        {
                                        border: 1px solid #ddd;
                                        padding: 8px;
                                        }

            #customers tr:nth-child(even){background-color: #f2f2f2;}

            #customers tr:hover {background-color: #ddd;}

            #customers th
                        {
                        padding-top: 12px;
                        padding-bottom: 12px;
                        text-align: left;
                        background-color: #04AA6D;
                        color: white;
                        }

        tr td:first-child:before
                            {
                            counter-increment: Serial;      
                            content: counter(Serial); 
                            }
        </style>
    </head>

    <body>
    <script href="js/unseen.js"></script>
            <div class='form_c'>
                <form align='center' action='' method='POST'>
                    <button name='continue' class='button7'>Continue</button>
                    <button name='discontinue' class='button8'>Discontinued</button>
            </div>
        <div class='form_b' style='overflow:scroll'>
                <table id="customers">
                    <tr>
                        <th>Sl No.</th>
                        <th>Select</th>
                        <th>Employee Name</th>
                        <th>Employee Code</th>
                        <th>Designation</th>
                        <th>Username</th>
                        <th>Current Status</th>
                    </tr>

                    <?php
                    $cstatus="";
                        $view_table="SELECT * FROM users ORDER BY name";
                        if($result=mysqli_query($con,$view_table))
                        {
                            if(mysqli_num_rows($result) > 0)
                            {
                                while($row = mysqli_fetch_array($result))
                                {
                                    if($row['cstatus']==0)
                                    {
                                        $cstatus="Discontinued";
                                    }
                                    if($row['cstatus']==1)
                                    {
                                        $cstatus="Continue";
                                    }
                                     
                                    echo "<tr>";
                                        echo "<td></td>";
                                        echo "<td><input type='radio' name='uid' value='".$row['id']."'></td>";
                                        echo "</form>";
                                        echo "<td>".$row['name']."</td>";
                                        echo "<td>".$row['emp_code']."</td>";
                                        echo "<td>".$row['userrole']."</td>";
                                        echo "<td>".$row['username']."</td>";
                                        echo "<td>".$cstatus."</td>";
                                    echo "</tr>";
                                }
                            }
                        }
                    ?>

                </table>
        </div>
    </body>
</html>
<html>
    <head>
        <title>IT SOLUTION</title>
        <link href='css/sheet1.css' rel='stylesheet'/>
        <link href='/asset/banner/favicon.png' rel='icon'/>
        <style>
                body
                    {
                        background-image: url('asset/banner/banner.png');
                        background-repeat: no-repeat;
                        background-size: 100% 100%;
                        z-index: -999;
                    }
        </style>
    </head>

    <body>
        <script src='unseen.js'></script>
        <form action='' method='POST'>
            <button class='button1' name='AdminLogin'>Admin Login</button>
            <button class='button2' name='Support_Login'>Support Login</button>
            <button class='button3' name='DeveloperLogin'>Developer & Designer Login</button>
            <button class='button3' name='changelog'>Change Log & Credits</button>
        </form>

    </body>
</html>

<?php
    if(isset($_POST['AdminLogin'])) {header("location: admin/");}
    if(isset($_POST['Support_Login'])) {header("location: support/");}
    if(isset($_POST['DeveloperLogin'])) {header("location: developer/");}
    if(isset($_POST['changelog'])) {header("location: changelog.php");}
?>
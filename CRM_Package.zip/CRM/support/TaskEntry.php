<?php
    include ('appcode/session.php');
    include ('appcode/config.php');
    include ('master.php');
    $alert="";
?>

<?php
    if(isset($_POST['SaveTask']))
    {
        $CollegeName=$_POST['CollegeName'];
        $ddate=$_POST['ddate'];
        $notes=$_POST['notes'];
        $entryby=$_POST['entryby'];
        $datafile=$_FILES['file']['name'];

        $ext=pathinfo($datafile, PATHINFO_EXTENSION);
        $newname = date('Ymd-his-l').".".$ext;
        $path="upload/";

            if(move_uploaded_file($_FILES['file']['tmp_name'],$path.$newname))
            {
                $task_entry="INSERT INTO task_info (college_name,ddate,notes,datafile,entry_by,work_status,deleted)VALUES
                ('$CollegeName','$ddate','$notes','$newname','$entryby','0','0')";

                    if(mysqli_query($con,$task_entry))
                    {
                        $alert="Task Entry Successful!";
                    }
                    else
                        {
                            $alert=mysqli_error($con);
                        }
            }
            else
                {
                    $alert=mysqli_error($con);
                }
    }
?>


<html>
    <head>
        <title>Task Entry | Support</title>
        <link href='css/sheet2.css' rel='stylesheet'/>
        <link href='/asset/banner/favicon.png' rel='icon'/>

        <style>
                body
                    {
                        background-image: url('src/banner.jpg');
                        background-repeat: no-repeat;
                        background-size: 100% 100%;
                        z-index: -999;
                    }
        </style>
    </head>

    <body>
    <script src="js/unseen.js"></script>
                <form class='form_a' align='center' action='' method='POST' enctype='multipart/form-data'>
                            <div style='font-size:30px;font-wight:bold;'>Task Entry</div><hr>
                    <input class='input_fild' name='CollegeName' type='text' placeholder='College Name'/> <br><br>
                    <input class='input_fild' name='ddate' type='date' placeholder='Pick a Date'/> <br><br>
                    
                    <textarea class='input_fild' name='notes' placeholder='Write here.....'></textarea><br><br>
                    <input class='input_fild' name='entryby' type='text' value='<?php echo $_SESSION['reg'];?>' readonly/> <br><br>
                    <input class='input_fild' name='file' type='file' multiple/> <br><br>
                        <?php echo "<div class='alert'>".$alert."</div>";?>
                    <button class='button8' name='SaveTask'>Save It</button> &nbsp; &nbsp;<input type='reset' class='button7' value='Reset'/>
                </form>
    </body>
</html>

<html>
    <head>
    <link href="/asset/banner/favicon.png" rel="icon">
        <style>
            .navbar
                    {
                        overflow: hidden;
                        background-color: #333;
                        width: 101.5%;
                        margin-left: -1%;
                        margin-top: -1%;
                    }

            .navbar a
                    {
                        float: left;
                        font-size: 16px;
                        color: white;
                        font-weight:bold;
                        font-family: 'Times New Roman', Times, serif;
                        text-align: center;
                        padding: 1% 3%;
                        text-decoration: none;
                    }

            .subnav
                    {
                        float: left;
                        overflow: hidden;
                    }

            .subnav .subnavbtn
                            {
                                font-size: 16px;  
                                border: none;
                                outline: none;
                                color: white;
                                padding: 14px 16px;
                                background-color: inherit;
                                font-family: inherit;
                                margin: 0;
                                font-weight: bold;
                            }

            .navbar a:hover, .subnav:hover .subnavbtn {background-color: dodgerblue;}

            .subnav-content
                            {
                                display: none;
                                position: absolute;
                                left: 0;
                                background-color: dodgerblue;
                                width: 100%;
                                z-index: 1;
                            }

            .subnav-content a
                            {
                                float: left;
                                color: white;
                                text-decoration: none;
                            }

            .subnav-content a:hover {
                                        background-color: #eee;
                                        color: black;
                                    }

            .subnav:hover .subnav-content {display: block;}
        </style>

        <body>
        <script src="js/unseen.js"></script>
            <div class="navbar">
                <a href='supportdashboard'>Home</a>

                <div class="subnav">
                    <button class="subnavbtn">Task Area <i class="fa fa-caret-down"></i></button>
                        <div class="subnav-content">
                            <a href="TaskEntry">Task Entry</a>
                            <a href="TaskAllotment">Task Allotment</a>
                        </div>
                </div>

                <div class="subnav">
                    <button class="subnavbtn">Work Status<i class="fa fa-caret-down"></i></button>
                        <div class="subnav-content">
                            <a href="work_status">Work Report</a>
                            <a href="deletedwork">Deleted Work</a>
                        </div>
                </div>

                <div class="subnav">
                    <button class="subnavbtn">My Task<i class="fa fa-caret-down"></i></button>
                        <div class="subnav-content">
                            <a href="MyTask">My Task</a>
                        </div>
                </div>

                <a href='logout'>Logout</a>

            </div>
               
        </body>
    </head>
</html>
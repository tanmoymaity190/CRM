<?php

    include ('appcode/session.php');

    include ('appcode/config.php');

    include ('master.php');

    $alert="";

?>



<html>

    <head>

        <title>User Status | Admin</title>

        <link href='css/sheet2.css' rel='stylesheet'/>

        <link href='/asset/banner/favicon.png' rel='icon'/>

        <style>

            body

                    {

                        background-image: url('src/banner.jpg');

                        background-repeat: no-repeat;

                        background-size: 100% 100%;

                        z-index: -999;

                        counter-reset: Serial;

                    }

            .alert

                    {

                        color: red;

                        font-size: large;

                        font-family: 'Times New Roman', Times, serif

                    }

            #customers

                    {

                    font-family: Arial, Helvetica, sans-serif;

                    border: 1px solid black;

                    border-collapse: collapse;

                    width: 100%;

                    text-align:center;

                    }



            #customers td, #customers th

                                        {

                                        border: 1px solid black;

                                        padding: 8px;

                                        }



            #customers tr:nth-child(even){background-color: #f2f2f2; border: 1px solid black;}



            #customers tr:hover {background-color: #ddd; border: 1px solid black;}



            #customers th

                        {

                        padding-top: 12px;

                        padding-bottom: 12px;

                        text-align: center;

                        background-color: #04AA6D;

                        color: white;

                        border: 1px solid black;

                        }



        tr td:first-child:before

                            {

                            counter-increment: Serial;      

                            content: counter(Serial); 

                            }

        </style>

    </head>



    <body>
    <script src="js/unseen.js"></script>
        

        <form class='form_c' action='ReportPrint.php' method='POST' style='width:90%' align='center'>

            <button name='CWCW' class='button7' style='width:25%'>College Wise Completed Work </button>

            <button name='DWCW' class='button7' style='width:25%'>Date Wise Completed Work </button>

            <button name='CWIW' class='button8' style='width:24%'>College Wise Inompleted Work </button>

            <button name='DWIW' class='button8' style='width:24%'>Date Wise Inompleted Work </button>

        </form>



    </body>

</html>
<?php
    $alert="";
    if(isset($_POST['adlogin']))
    {
        include ('appcode/config.php');

        $username=$_POST['aduname'];
        $password=$_POST['adpasswd'];
            $epass=md5($password);

        $login_query="SELECT * FROM users WHERE username='$username' AND password='$epass' AND userrole='Supporter' AND cstatus='1'";

        if(mysqli_query($con,$login_query))
        {
            $result=mysqli_query($con,$login_query);
            $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
            $count=mysqli_num_rows($result);

                if($count==1)
                {
                    session_start();
                    $_SESSION['suloggedin']=true;
                    $_SESSION["id"] = $id;
					$_SESSION["username"] = $username;
                    header("location: supportdashboard.php");
                    exit();
                }

                else
                    {
                        $alert="Login Failed!";
                    }
        }
    }
?>
<html>
    <head>
        <title>Support Login</title>
        <link href='css/sheet2.css' rel='stylesheet'/>
        <link href='/asset/banner/favicon.png' rel='icon'/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <body>
    <script src="js/unseen.js"></script>
        <form class='Login' action='' method='POST' align='center'>
            <div style='font-size:140px'><i class="fa fa-ticket" aria-hidden="true"></i></div>
            <div style='font-size:40px;font-weight:bold'>Support Login</div>
            <span class=''></span>
                <input type='text' name='aduname' class='input_fild' placeholder='Username'/>
                    <br><br>

            <span class=''></span>
                <input type='password' name='adpasswd' class='input_fild' placeholder='Password'/>
                    <br><br>
                    <?php echo "<div class='alert'>".$alert."</div>";?>
            <button class='button5' name='adlogin'>Login</button>
                        &nbsp;&nbsp;
            <input class='button6' value='Reset' type='reset'/>
            
        </form>
    </body>
</html>
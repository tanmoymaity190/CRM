<?php
	session_start();
	   if(!isset($_SESSION["suloggedin"]) || $_SESSION["suloggedin"] !== true)
	   {
		 header("location: supportlogin.php");
		 exit();
	  } 
?>
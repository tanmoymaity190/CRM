<?php
    include ('appcode/session.php');
    include ('appcode/config.php');
    $alert="";
?>


<html>
    <head>
    <link href='css/sheet2.css' rel='stylesheet'/>
    <link href='/asset/banner/favicon.png' rel='icon'/>
    <title>Report</title>
<style>
    body
    {
        background-color:white;
        counter-reset: Serial;
    }
    #customers
                    {
                    font-family: Arial, Helvetica, sans-serif;
                    border: 1px solid black;
                    border-collapse: collapse;
                    width: 100%;
                    text-align:center;
                    }

            #customers td, #customers th
                                        {
                                        border: 1px solid black;
                                        padding: 8px;
                                        }

            #customers tr:nth-child(even){background-color: #f2f2f2; border: 1px solid black;}

            #customers tr:hover {background-color: #ddd; border: 1px solid black;}

            #customers th
                        {
                        padding-top: 12px;
                        padding-bottom: 12px;
                        text-align: center;
                        background-color: #04AA6D;
                        color: white;
                        border: 1px solid black;
                        }

        tr td:first-child:before
                            {
                            counter-increment: Serial;      
                            content: counter(Serial); 
                            }
        </style>
</style>
                        </head>

                        <body>
                        <script src="js/unseen.js"></script>
<div class='form_c' align='center' style='width:90%'>
            <button name='print'  onclick="printDiv('PrintMe')" class='button7'>Print Report </button>
            <button name='back' onclick="history.back()" class='button7'>Back</button>
        </div>

<script>
    function printDiv(divName)
    {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }
</script>



        <?php

            //College Wise Completed Work Report

            if(isset($_POST['CWCW']))
            {
                    echo "<div id='PrintMe'>"; //Printing DIV
                    echo "<h2 align='center'>College Wise Completed Work</h2>";
                    date_default_timezone_set("Asia/Calcutta");
                    echo"<div style='float:right;'>Generated on: ".date('d/m/Y  h:i:s a')."</div>";
                    echo"<table id='customers'>";
                        echo"<tr>";
                            echo"<th>Sl No.</th>";
                            echo"<th>Date</th>";
                            echo"<th>Entry By</th>";
                            echo"<th>College Name</th>";
                            echo"<th>Attachment</th>";
                            echo"<th>Notes</th>";
                            echo"<th>Alloted To</th>";
                            echo"<th>Work Status</th>";
                        echo "</tr>";

                        $query1="SELECT * FROM task_info WHERE work_status=1 AND deleted='0' ORDER BY college_name ASC";
                        if($result=mysqli_query($con,$query1))
                        {
                            if(mysqli_num_rows($result) > 0)
                            {
                                while($row = mysqli_fetch_array($result))
                                {
                                    $originalDate = $row['ddate'];
                                    $newDate = date("d/m/Y", strtotime($originalDate));
                                    $originalDate1 = $row['develop_on'];
                                    $newDate1 = date("d/m/Y", strtotime($originalDate1));
                                    
                                    echo"<form align='center' action='' method='POST'>";

                                    echo "<tr>";
                                        echo "<td></td>";
                                        echo "<td>".$newDate."</td>";
                                        echo "<td>".$row['entry_by']."</td>";
                                        echo "<td>".$row['college_name']."</td>";
                                        echo "<td><a href='upload/".$row['datafile']."'>Attached File</a></td>";
                                        echo "<td>".$row['notes']."</td>";
                                        echo "<td>".$row['alloted_to']."</td>";
                                        if($row['work_status']==1){$wst="Done";}
                                        echo"<td>".$wst." (".$newDate1.")</td>";
                                    echo "</tr>";
                                }
                            }
                        }
                echo"</table>";
                echo"</div>";
      
            }





 //Date Wise Completed Work Report

            if(isset($_POST['DWCW']))
            {
                echo"<div class='form_b' style='overflow:scroll;width:98%'>";
                echo "<div id='printMe'>"; //Printing DIV
                echo "<h2 align='center'>Date Wise Completed Work</h2>";
                    date_default_timezone_set("Asia/Calcutta");
                    echo"<div style='float:right;'>Generated on: ".date('d/m/Y  h:i:s a')."</div>";
                    echo"<table id='customers'>";
                        echo"<tr>";
                            echo"<th>Sl No.</th>";
                            echo"<th>Date</th>";
                            echo"<th>Entry By</th>";
                            echo"<th>College Name</th>";
                            echo"<th>Attachment</th>";
                            echo"<th>Notes</th>";
                            echo"<th>Alloted To</th>";
                            echo"<th>Work Status</th>";
                        echo "</tr>";

                        $query1="SELECT * FROM task_info WHERE work_status=1 ORDER BY ddate ASC";
                        if($result=mysqli_query($con,$query1))
                        {
                            if(mysqli_num_rows($result) > 0)
                            {
                                while($row = mysqli_fetch_array($result))
                                {
                                    $originalDate = $row['ddate'];
                                    $newDate = date("d/m/Y", strtotime($originalDate));
                                    $originalDate1 = $row['develop_on'];
                                    $newDate1 = date("d/m/Y", strtotime($originalDate1));
                                    
                                    echo"<form align='center' action='' method='POST'>";

                                    echo "<tr>";
                                        echo "<td></td>";
                                        echo "<td>".$newDate."</td>";
                                        echo "<td>".$row['entry_by']."</td>";
                                        echo "<td>".$row['college_name']."</td>";
                                        echo "<td><a href='upload/".$row['datafile']."'>Attached File</a></td>";
                                        echo "<td>".$row['notes']."</td>";
                                        echo "<td>".$row['alloted_to']."</td>";
                                        if($row['work_status']==1){$wst="Done";}
                                        echo"<td>".$wst." (".$newDate1.")</td>";
                                    echo "</tr>";
                                }
                            }
                        }
                echo"</table>";
                echo"</div>";
        echo"</div>";
            }





 //College Wise Inompleted Work Report

 if(isset($_POST['CWIW']))
 {
     echo"<div class='form_b' style='overflow:scroll;width:98%'>";
     echo "<div id='printMe'>"; //Printing DIV
     echo "<h2 align='center'>College Wise Inompleted Work</h2>";
         date_default_timezone_set("Asia/Calcutta");
         echo"<div style='float:right;'>Generated on: ".date('d/m/Y  h:i:s a')."</div>";
         echo"<table id='customers'>";
             echo"<tr>";
                 echo"<th>Sl No.</th>";
                 echo"<th>Date</th>";
                 echo"<th>Entry By</th>";
                 echo"<th>College Name</th>";
                 echo"<th>Attachment</th>";
                 echo"<th>Notes</th>";
                 echo"<th>Alloted To</th>";
                 echo"<th>Work Status</th>";
             echo "</tr>";

             $query1="SELECT * FROM task_info WHERE work_status=0 ORDER BY college_name ASC";
             if($result=mysqli_query($con,$query1))
             {
                 if(mysqli_num_rows($result) > 0)
                 {
                     while($row = mysqli_fetch_array($result))
                     {
                         $originalDate = $row['ddate'];
                         $newDate = date("d/m/Y", strtotime($originalDate));
                         $originalDate1 = $row['develop_on'];
                         $newDate1 = date("d/m/Y", strtotime($originalDate1));
                         
                         echo"<form align='center' action='' method='POST'>";

                         echo "<tr>";
                             echo "<td></td>";
                             echo "<td>".$newDate."</td>";
                             echo "<td>".$row['entry_by']."</td>";
                             echo "<td>".$row['college_name']."</td>";
                             echo "<td><a href='upload/".$row['datafile']."'>Attached File</a></td>";
                             echo "<td>".$row['notes']."</td>";
                             echo "<td>".$row['alloted_to']."</td>";
                             if($row['work_status']==0){$wst="Not Done";}
                             echo"<td>".$wst." (".$newDate1.")</td>";
                         echo "</tr>";
                     }
                 }
             }
     echo"</table>";
     echo"</div>";
echo"</div>";
 }




 //Date Wise Inompleted Work Report

 if(isset($_POST['DWIW']))
 {
     echo"<div class='form_b' style='overflow:scroll;width:98%'>";
     echo "<div id='printMe'>"; //Printing DIV
     echo "<h2 align='center'>Date Wise Inompleted Work</h2>";
         date_default_timezone_set("Asia/Calcutta");
         echo"<div style='float:right;'>Generated on: ".date('d/m/Y  h:i:s a')."</div>";
         echo"<table id='customers'>";
             echo"<tr>";
                 echo"<th>Sl No.</th>";
                 echo"<th>Date</th>";
                 echo"<th>Entry By</th>";
                 echo"<th>College Name</th>";
                 echo"<th>Attachment</th>";
                 echo"<th>Notes</th>";
                 echo"<th>Alloted To</th>";
                 echo"<th>Work Status</th>";
             echo "</tr>";

             $query1="SELECT * FROM task_info WHERE work_status=0 ORDER BY ddate ASC";
             if($result=mysqli_query($con,$query1))
             {
                 if(mysqli_num_rows($result) > 0)
                 {
                     while($row = mysqli_fetch_array($result))
                     {
                         $originalDate = $row['ddate'];
                         $newDate = date("d/m/Y", strtotime($originalDate));
                         $originalDate1 = $row['develop_on'];
                         $newDate1 = date("d/m/Y", strtotime($originalDate1));
                         
                         echo"<form align='center' action='' method='POST'>";

                         echo "<tr>";
                             echo "<td></td>";
                             echo "<td>".$newDate."</td>";
                             echo "<td>".$row['entry_by']."</td>";
                             echo "<td>".$row['college_name']."</td>";
                             echo "<td><a href='upload/".$row['datafile']."'>Attached File</a></td>";
                             echo "<td>".$row['notes']."</td>";
                             echo "<td>".$row['alloted_to']."</td>";
                             if($row['work_status']==0){$wst="Not Done";}
                             echo"<td>".$wst." (".$newDate1.")</td>";
                         echo "</tr>";
                     }
                 }
             }
     echo"</table>";
     echo"</div>";
echo"</div>";
 }
 ?>
 </body>
 </html>
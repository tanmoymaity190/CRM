<?php

    include ('appcode/session.php');

    include ('master.php');

    include ('appcode/config.php');

?>



<?php

   $vusername=$_SESSION['username'];

   $sql1 = "SELECT * FROM users WHERE username='$vusername'";

       if($result = mysqli_query($con,$sql1))

           {

               if(mysqli_num_rows($result) > 0)

                   {

                       while($row = mysqli_fetch_array($result))

                           {

                               $_SESSION['reg']=$row['name'];

                           }

                   }

           }

?>



<html>

    <head>

        <title>Support Dashboard</title>

        <link href='/asset/banner/favicon.png' rel='icon'/>

        <style>

                body

                    {

                        background-image: url('src/banner.jpg');

                        background-repeat: no-repeat;

                        background-size: 100% 100%;

                        z-index: -999;

                    }

                

                .portal

                        {

                            color:white;

                            font-size:35px;

                            margin-left:66%;

                            margin-top:20%

                        }

        </style>

    </head>



    <body>
    <script src="js/unseen.js"></script>
        <div class='portal'>Support Portal</div>

    </body>

</html>
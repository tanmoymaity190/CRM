<?php

    include ('appcode/session.php');

    include ('appcode/config.php');

    include ('master.php');

    $alert="";

?>



<html>

    <head>

        <title>User Status | Admin</title>

        <link href='css/sheet2.css' rel='stylesheet'/>

        <link href='/asset/banner/favicon.png' rel='icon'/>

        <style>

            body

                    {

                        background-image: url('src/banner.jpg');

                        background-repeat: no-repeat;

                        background-size: 100% 100%;

                        z-index: -999;

                        counter-reset: Serial;

                    }

            .alert

                    {

                        color: red;

                        font-size: large;

                        font-family: 'Times New Roman', Times, serif

                    }

            #customers

                    {

                    font-family: Arial, Helvetica, sans-serif;

                    border-collapse: collapse;

                    width: 100%;

                    text-align:center;

                    }



            #customers td, #customers th

                                        {

                                        border: 1px solid #ddd;

                                        padding: 8px;

                                        }



            #customers tr:nth-child(even){background-color: #f2f2f2;}



            #customers tr:hover {background-color: #ddd;}



            #customers th

                        {

                        padding-top: 12px;

                        padding-bottom: 12px;

                        text-align: left;

                        background-color: #04AA6D;

                        color: white;

                        }



        tr td:first-child:before

                            {

                            counter-increment: Serial;      

                            content: counter(Serial); 

                            }

        </style>

    </head>



        <?php

            if(isset($_POST['restore']))

            {

                $pid=$_POST['pid'];

                $restore_query="UPDATE task_info SET deleted='0' WHERE id='$pid'";



                if(mysqli_query($con, $restore_query))

                {

                    $alert="Work Restored Successfully!";

                }

            }



            if(isset($_POST['delete']))

            {

                $pid=$_POST['pid'];

                $delete_query="DELETE FROM task_info WHERE id='$pid'";



                if(mysqli_query($con, $delete_query))

                {

                    $alert="Work Deleted Permanently!";

                }

            }

        ?>



    <body>
            <script src="js/unseen.js"></script>
        <div class='form_b' style='overflow:scroll;width:98%'>

                <table id="customers">

                    <tr>

                        <th>Sl No.</th>

                        <th>Select</th>

                        <th>Date</th>

                        <th>Entry By</th>

                        <th>College Name</th>

                        <th>Attachment</th>

                        <th>Notes</th>

                        <th>Alloted To</th>

                        <th>Work Status</th>

                    </tr>



                    <?php

                        $view_table="SELECT * FROM task_info WHERE deleted='1' ORDER BY ddate";

                        if($result=mysqli_query($con,$view_table))

                        {

                            if(mysqli_num_rows($result) > 0)

                            {

                                while($row = mysqli_fetch_array($result))

                                {

                                    $originalDate = $row['ddate'];

                                    $newDate = date("d/m/Y", strtotime($originalDate));

                                    

                                    echo"<form align='center' action='' method='POST'>";



                                    echo "<tr>";

                                        echo "<td></td>";

                                        echo "<td><input type='radio' name='pid' value='".$row['id']."'></td>";

                                        echo "<td>".$newDate."</td>";

                                        echo "<td>".$row['entry_by']."</td>";

                                        echo "<td>".$row['college_name']."</td>";

                                        echo "<td><a href='upload/".$row['datafile']."'>Attached File</a></td>";

                                        echo "<td>".$row['notes']."</td>";

                                        echo "<td>".$row['alloted_to']."</td>";

                                        echo "<td>".$row['work_status']."</td>";

                                    echo "</tr>";

                                }

                            }

                        }

                    ?>

                </table>

        </div>



        <div class='form_c'  align='center' style='width:30%'>

                    <br><br><?php echo "<div class='alert'>".$alert."</div>";?>

                    <button name='restore' class='button8'>Restore</button><br><br>

                    <button name='delete' style='width:53%' class='button7'>Permanently Delete</button>

                    </form>

        </div>

    </body>

</html>